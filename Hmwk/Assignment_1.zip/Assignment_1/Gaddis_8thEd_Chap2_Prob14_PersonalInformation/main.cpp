/* 
 * File:   main.cpp
 * Author: Joel Avalos
 * Created on January 7, 2018, 10:22 AM
 * Purpose: To display several pieces of information with a single cout
 * statement.
 */
 
 //System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    
    //Initialize Variables
    
    
    //Process/Map inputs to outputs
    
            
    //output data
    cout<<"Hello! Here is some of my personal information at no cost to you!\n"
    <<"Joel Avalos\n"<<"20338 Lyon Road, Riverside, California, 92507\n"
    <<"(909) 452-1952\n"<<"Mathematics major\n"<<endl;
    
            
    //Exit stage right!
    return 0;
}

